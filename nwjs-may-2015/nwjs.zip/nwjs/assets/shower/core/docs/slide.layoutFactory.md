**Overview:** Layout factory for slides.
* * *


====
#### .layoutFactory () 




====
#### .createLayout (parameters, parameters.content, parameters.contentType) 

Parameters:<br>
— ***parameters***: `object`<br>
— ***parameters.content***: `string`, Slide content.<br>
— ***parameters.contentType***: `string`, Cover, slide, image.<br>

**Returns**: `slide.Layout`




* * *




