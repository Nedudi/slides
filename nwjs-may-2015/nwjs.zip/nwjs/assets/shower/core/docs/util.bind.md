**Overview:** Simple bind without currying.
* * *


====
#### .bind (fn, ctx) 

Parameters:<br>
— ***fn***: `function`, Function.<br>
— ***ctx***: `object`, Context.<br>





* * *




