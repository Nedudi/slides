


## event.Event

Event class. Can contains custom data.




====
#### .get (key) 

Parameters:<br>
— ***key***: `string`<br>

**Returns**: `object`



* * *




