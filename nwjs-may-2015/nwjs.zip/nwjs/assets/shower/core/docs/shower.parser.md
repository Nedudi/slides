

====
#### .parser. (containerElement, cssSelector) 

Parameters:<br>
— ***containerElement***: `HTMLElement`<br>
— ***cssSelector***: `string`<br>

**Returns**: `Array.&lt;Slide&gt;`




* * *




