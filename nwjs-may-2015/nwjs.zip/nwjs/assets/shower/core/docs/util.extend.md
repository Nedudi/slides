

====
#### .extend (target, source) 

Parameters:<br>
— ***target***: `object`<br>
— ***source***: `object`<br>

**Returns**: `object`, Extended target object.




* * *




